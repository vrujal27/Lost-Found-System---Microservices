import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend, LabelList, CartesianGrid } from 'recharts';
import './index.css';

const API_BASE = {
  lost: 'http://localhost:3001',
  found: 'http://localhost:3002',
  saga: 'http://localhost:3005'
};

function App() {
  const [lostItems, setLostItems] = useState([]);
  const [foundItems, setFoundItems] = useState([]);
  
  const [lostForm, setLostForm] = useState({ item: '', location: '' });
  const [foundForm, setFoundForm] = useState({ item: '', location: '' });

  const fetchData = async () => {
    try {
      const lostRes = await fetch(`${API_BASE.lost}/lost`);
      if(lostRes.ok) setLostItems(await lostRes.json());

      const foundRes = await fetch(`${API_BASE.found}/found`);
      if(foundRes.ok) setFoundItems(await foundRes.json());
    } catch(err) {
      console.error("Error fetching data:", err);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleReportLost = async (e) => {
    e.preventDefault();
    if (!lostForm.item || !lostForm.location) return;
    try {
      await fetch(`${API_BASE.lost}/lost`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(lostForm)
      });
      setLostForm({ item: '', location: '' });
      fetchData();
    } catch (err) {
      alert("Failed to report lost item.");
    }
  };

  const handleReportFound = async (e) => {
    e.preventDefault();
    if (!foundForm.item || !foundForm.location) return;
    try {
      await fetch(`${API_BASE.found}/found`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(foundForm)
      });
      setFoundForm({ item: '', location: '' });
      fetchData();
    } catch (err) {
      alert("Failed to report found item.");
    }
  };

  const handleReturnItem = async (lostItemId, foundItemId) => {
    try {
      const res = await fetch(`${API_BASE.saga}/api/saga/return-item`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lostItemId, foundItemId })
      });
      const data = await res.json();
      if(res.ok) {
        alert(data.message || "Saga Completed! Items safely returned.");
        fetchData();
      } else {
        alert("Saga Error: " + data.error);
      }
    } catch (err) {
      alert("Failed to contact Orchestrator.");
    }
  };

  const getMatches = () => {
    const activeLost = lostItems.filter(i => (!i.status || i.status === 'OPEN'));
    const activeFound = foundItems.filter(i => (!i.status || i.status === 'OPEN'));
    const matches = [];

    activeLost.forEach(lost => {
      activeFound.forEach(found => {
        const lItem = lost.item.toLowerCase().trim();
        const fItem = found.item.toLowerCase().trim();
        const lLoc = lost.location.toLowerCase().trim();
        const fLoc = found.location.toLowerCase().trim();

        if ((lItem.includes(fItem) || fItem.includes(lItem)) && 
            (lLoc.includes(fLoc) || fLoc.includes(lLoc))) {
          matches.push({ lost, found });
        }
      });
    });
    return matches;
  };

  const matches = getMatches();

  const stats = {
    totalLost: lostItems.length,
    activeLost: lostItems.filter(i => i.status === 'OPEN').length,
    totalFound: foundItems.length,
    activeFound: foundItems.filter(i => i.status === 'OPEN').length,
    resolvedLost: lostItems.filter(i => i.status === 'RESOLVED').length,
    resolvedFound: foundItems.filter(i => i.status === 'RESOLVED').length
  };

  const statusData = [
    { name: 'Active Lost', value: stats.activeLost, color: '#0ea5e9' },
    { name: 'Active Found', value: stats.activeFound, color: '#8b5cf6' },
    { name: 'Successfully Returned', value: stats.resolvedLost, color: '#10b981' }
  ];

  const last7Days = Array.from({length: 7}, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - i);
    return d.toLocaleDateString();
  }).reverse();

  const activityData = last7Days.map(date => {
    return {
      date: date.substring(0, 5),
      lost: lostItems.filter(i => new Date(i.createdAt).toLocaleDateString() === date).length,
      found: foundItems.filter(i => new Date(i.createdAt).toLocaleDateString() === date).length
    };
  });

  const customTooltipStyle = {
    background: '#ffffff',
    border: 'none',
    borderRadius: '1rem',
    color: '#0f172a',
    boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.025)'
  };

  return (
    <div className="dashboard-container">
      
      <header className="header">
        <h1>Lost & Found Portal</h1>
        <p>Real-time microservices coordination dashboard.</p>
      </header>

      <main className="bento-grid">
        
        {/* ROW 1: Stats & Forms */}
        
        {/* Left Column: Stacked Stats */}
        <div className="bento-stats-col">
          <div className="stat-widget">
            <h3>Active Lost Items</h3>
            <div className="stat-value text-sky">{stats.activeLost}</div>
          </div>
          <div className="stat-widget">
            <h3>Active Found Items</h3>
            <div className="stat-value text-violet">{stats.activeFound}</div>
          </div>
          <div className="stat-widget" style={{ background: '#0f172a' }}>
            <h3 style={{ color: '#94a3b8' }}>Successfully Returned</h3>
            <div className="stat-value text-emerald">{stats.resolvedLost}</div>
          </div>
        </div>

        {/* Middle Column: Report Lost Form */}
        <div className="bento-card bento-form-lost">
          <h2>Report Lost Item</h2>
          <form onSubmit={handleReportLost}>
            <div className="form-group">
              <label>Item Description</label>
              <input 
                type="text" 
                className="form-input input-lost" 
                value={lostForm.item} 
                onChange={e => setLostForm({...lostForm, item: e.target.value})} 
                placeholder="e.g. Blue Macbook Pro"
                required 
              />
            </div>
            <div className="form-group">
              <label>Location Lost</label>
              <input 
                type="text" 
                className="form-input input-lost" 
                value={lostForm.location} 
                onChange={e => setLostForm({...lostForm, location: e.target.value})} 
                placeholder="e.g. Central Library"
                required 
              />
            </div>
            <button type="submit" className="btn btn-primary">Submit Lost Report</button>
          </form>
        </div>

        {/* Right Column: Report Found Form */}
        <div className="bento-card bento-form-found">
          <h2>Report Found Item</h2>
          <form onSubmit={handleReportFound}>
            <div className="form-group">
              <label>Item Description</label>
              <input 
                type="text" 
                className="form-input input-found" 
                value={foundForm.item} 
                onChange={e => setFoundForm({...foundForm, item: e.target.value})} 
                placeholder="e.g. Leather Wallet"
                required 
              />
            </div>
            <div className="form-group">
              <label>Location Found</label>
              <input 
                type="text" 
                className="form-input input-found" 
                value={foundForm.location} 
                onChange={e => setFoundForm({...foundForm, location: e.target.value})} 
                placeholder="e.g. Cafeteria"
                required 
              />
            </div>
            <button type="submit" className="btn btn-secondary">Submit Found Report</button>
          </form>
        </div>

        {/* ROW 2: Analytics Charts */}
        
        {/* Wide Bar Chart */}
        <div className="bento-card bento-chart-bar">
          <h2>Recent Activity (7 Days)</h2>
          <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={activityData} margin={{ top: 20, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(0,0,0,0.05)" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} allowDecimals={false} />
                <RechartsTooltip cursor={{ fill: 'rgba(0,0,0,0.02)' }} contentStyle={customTooltipStyle} />
                <Legend verticalAlign="top" height={36} wrapperStyle={{ paddingBottom: '10px' }}/>
                <Bar dataKey="lost" name="Lost Reports" fill="var(--accent-sky)" radius={[6, 6, 0, 0]}>
                  <LabelList dataKey="lost" position="top" fill="var(--accent-sky)" fontSize={12} fontWeight="bold" formatter={(val) => val > 0 ? val : ''} />
                </Bar>
                <Bar dataKey="found" name="Found Reports" fill="var(--accent-violet)" radius={[6, 6, 0, 0]}>
                  <LabelList dataKey="found" position="top" fill="var(--accent-violet)" fontSize={12} fontWeight="bold" formatter={(val) => val > 0 ? val : ''} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Compact Pie Chart */}
        <div className="bento-card bento-chart-pie">
          <h2>Current Distribution</h2>
          <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie 
                  data={statusData} cx="50%" cy="50%" innerRadius={60} outerRadius={85} paddingAngle={2} dataKey="value"
                  label={({ name, value }) => value > 0 ? `${value}` : ''}
                  labelLine={false}
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="#fff" strokeWidth={2}/>
                  ))}
                </Pie>
                <RechartsTooltip contentStyle={customTooltipStyle} itemStyle={{ color: '#0f172a', fontWeight: 'bold' }} />
                <Legend verticalAlign="bottom" height={40} wrapperStyle={{ paddingTop: '20px' }}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* ROW 3: Registries Lists */}

        <div className="bento-card bento-list-lost">
          <h2>Reported Lost Registry</h2>
          <div className="item-list">
            {[...lostItems].sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt)).map(item => (
              <div key={item._id} className="item-row">
                <div className="item-info">
                  <strong>{item.item}</strong>
                  <span>Lost at: {item.location}</span>
                </div>
                <span className={`status-badge status-${item.status?.toLowerCase() || 'open'}`}>
                  {(!item.status || item.status === 'OPEN') ? 'PENDING' : 'CLAIMED'}
                </span>
              </div>
            ))}
            {lostItems.length === 0 && <span style={{color: 'var(--text-muted)', padding: '1rem 0'}}>No lost items reported yet.</span>}
          </div>
        </div>
        
        <div className="bento-card bento-list-found">
          <h2>Reported Found Registry</h2>
          <div className="item-list">
            {[...foundItems].sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt)).map(item => (
              <div key={item._id} className="item-row">
                <div className="item-info">
                  <strong>{item.item}</strong>
                  <span>Found at: {item.location}</span>
                </div>
                <span className={`status-badge status-${item.status?.toLowerCase() || 'open'}`}>
                  {(!item.status || item.status === 'OPEN') ? 'PENDING' : 'CLAIMED'}
                </span>
              </div>
            ))}
            {foundItems.length === 0 && <span style={{color: 'var(--text-muted)', padding: '1rem 0'}}>No found items reported yet.</span>}
          </div>
        </div>

      </main>

      {/* Floating Match Notification */}
      {matches.length > 0 && (
        <div className="match-overlay">
          <h3>🎉 Potential Matches Detected!</h3>
          <p style={{ color: 'var(--text-muted)', marginBottom: '1rem', fontSize: '0.85rem' }}>
            The matching system has found items that might belong together. Verify and process the return.
          </p>
          <div className="item-list" style={{ maxHeight: '250px' }}>
            {matches.map((m, i) => (
              <div key={i} className="item-row" style={{ flexDirection: 'column', alignItems: 'stretch', gap: '0.75rem', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                <div className="item-info">
                  <strong>{m.lost.item}</strong>
                  <span>Lost: {m.lost.location} • Found: {m.found.location}</span>
                </div>
                <button className="btn btn-success" onClick={() => handleReturnItem(m.lost._id, m.found._id)}>
                  Claim & Return Item
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}

export default App;
