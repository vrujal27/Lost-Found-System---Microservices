# Steps to Start the Lost and Found Platform

There are two primary ways to run this project. **Method 1 is highly recommended** as it will automatically handle setting up all databases, message brokers, and running all microservices simultaneously.

---

## Method 1: Using Docker Compose (Recommended & Easiest)

This method spins up the entire application architecture, including MongoDB, MySQL, ActiveMQ, Redis, and all the individual microservices in one go.

### Prerequisites:
- Ensure you have **Docker Dashboard / Docker Desktop** installed and actively running on your machine.

### Steps:
1. Open up your terminal or command prompt.
2. Navigate to the root directory of the project (`lost-found-project`).
3. Run the following command:
   ```bash
   docker-compose up --build
   ```
4. Wait for Docker to download the necessary images and start all the containers. You will see logs from all the services appearing in your terminal.
5. Once everything has started, you can access the application:
   - **Frontend UI:** Go to `http://localhost:5173` in your web browser.
6. **To Stop:** Press `Ctrl + C` in the terminal where it's running, or run `docker-compose down` in another terminal in the same folder.

---

## Method 2: Running Services Manually (For Local Development)

If you need to work on a specific service or run them without the dockerized application containers, follow these steps. 

### Prerequisites:
- You must have **Node.js** installed.
- You still need the databases (MongoDB, MySQL, Redis, ActiveMQ) running. You can start *just* the infrastructure using Docker by running:
  ```bash
  docker-compose up mongodb mysql activemq redis phpmyadmin -d
  ```

### Steps:

You will need to open **6 separate terminal windows/tabs**.

**Terminal 1: Lost Service**
```bash
cd lost-service
npm install
npm run start   # or npm run dev if it's set up
```

**Terminal 2: Found Service**
```bash
cd found-service
npm install
npm run start   # or npm run dev
```

**Terminal 3: Match Service**
```bash
cd match-service
npm install
npm run start
```

**Terminal 4: Notification Service**
```bash
cd notification-service
npm install
npm run start
```

**Terminal 5: Orchestrator Service**
```bash
cd orchestrator-service
npm install
npm run start
```

**Terminal 6: Frontend**
```bash
cd frontend
npm install
npm run dev
```

After all manual terminals are up and running without errors, you can browse the frontend at `http://localhost:5173`.
