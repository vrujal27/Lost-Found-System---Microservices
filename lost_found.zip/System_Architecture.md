# Comprehensive System Architecture Guide

The **Lost and Found Project** uses a modern, **Polyglot Microservices Architecture**, integrated with asynchronous messaging (**Event-Driven Architecture**) and distributed transaction orchestration (**Saga Pattern**). This document outlines the inner workings, database schemas, and exact mechanisms of every service.

## High-Level Architecture Diagram

```mermaid
graph TD
    UI[Frontend Client<br/>Vite/React - Port 5173] --> orchestrator[Orchestrator Service<br/>Port 3005]
    UI --> lostapi[Lost Service API<br/>Port 3001]
    UI --> foundapi[Found Service API<br/>Port 3002]

    subgraph "Core Microservices"
        lostapi -->|Reads/Writes| mongo[(MongoDB<br/>Port 27017)]
        lostapi -->|Caches| redis[(Redis Cache<br/>Port 6379)]
        
        foundapi -->|Reads/Writes| mysql[(MySQL Database<br/>Port 3306)]
        
        orchestrator -->|Saga Pattern / REST| lostapi
        orchestrator -->|Saga Pattern / REST| foundapi
    end

    subgraph "Message Broker"
        broker{{ActiveMQ<br/>Port 61616}}
    end

    lostapi -->|Publishes via Circuit Breakers| broker
    foundapi -->|Publishes via Circuit Breakers| broker

    subgraph "Event-Driven Consumers"
        match[Match Service]
        notify[Notification Service]
    end

    broker -->|Consumes Events| match
    broker -->|Consumes Events| notify

    %% External tools
    phpmyadmin[phpMyAdmin<br/>Port 8080] -.-> mysql
```

---

## Detailed Service Specifications

### 1. Lost Item Service (Port 3001)
Written in Node.js/Express, this service exclusively handles the "Lost" domain.

**Primary Concepts:**
*   **Database:** MongoDB. Used for schema flexibility.
*   **Cache:** Redis. Used to handle high-read traffic on the dashboard.
*   **Queue Output:** `/queue/lost-items`
*   **Fault Tolerance:** Implements a `Circuit Breaker` (via *Opossum*) when pushing messages to ActiveMQ. If ActiveMQ is down, the item is still saved to MongoDB, preventing total system collapse, and the breaker triggers a fallback log.

**Endpoints:**
| Method | Route | Action |
| :--- | :--- | :--- |
| `POST` | `/lost` | Creates a new LostItem in MongoDB. Invalidates Redis cache instantly. Publishes event to ActiveMQ via Circuit Breaker. |
| `GET` | `/lost` | Fetches lost items. First checks Redis. If miss, queries MongoDB and sets Redis cache for 60 seconds (`TTL`). |
| `PATCH` | `/lost/:id` | **Saga Endpoint:** Changes status of an item. Invalidates Redis cache natively. |

**Database Schema (Mongoose):**
```javascript
{
    item: { type: String, required: true },
    location: { type: String, required: true },
    status: { type: String, default: 'OPEN' }, // States: OPEN, RESOLVED
    createdAt: { type: Date, default: Date.now }
}
```

---

### 2. Found Item Service (Port 3002)
Written in Node.js/Express, this service exclusively handles the "Found" domain.

**Primary Concepts:**
*   **Database:** MySQL (using *Sequelize* ORM). Used for stricter schema boundaries and relational tracking.
*   **Queue Output:** `/queue/found-items`
*   **Fault Tolerance:** Also implements an Opossum `Circuit Breaker` (Timeout: 3000ms, Error Threshold: 50%) for ActiveMQ availability redundancy.

**Endpoints:**
| Method | Route | Action |
| :--- | :--- | :--- |
| `POST` | `/found` | Creates a new FoundItem in MySQL. Publishes event to ActiveMQ via Circuit Breaker. |
| `GET` | `/found` | Returns all found items directly from MySQL. |
| `PATCH` | `/found/:id` | **Saga Endpoint:** Changes status of an item. |

**Database Schema (Sequelize):**
```javascript
{
  item: { type: DataTypes.STRING, allowNull: false },
  location: { type: DataTypes.STRING, allowNull: false },
  status: { type: DataTypes.STRING, defaultValue: 'OPEN' }
} // Includes standard Sequlize createdAt timestamp.
```

---

### 3. Match Service (Background Worker)
A headless Node.js service that acts as an intersection between the two primary event queues.

**Primary Concepts:**
*   **Queues Consumed:** `/queue/lost-items` AND `/queue/found-items`
*   **Queue Output:** `/queue/match`
*   **Database Read Access:** Connects directly (read-only theoretically, though implements full ORM instance) to *both* MongoDB and MySQL.

**Matching Algorithm Flow:**
1.  **When a LOST event fires:** It queries MySQL to see if an `OPEN` item exists with the exact `item` name (trimmed). If it finds one, it verifies the `location` string using a case-insensitive, whitespace-trimmed equality check. If it matches, it publishes a compound match payload to `/queue/match`.
2.  **When a FOUND event fires:** It queries MongoDB using a regex `/$^item$/i` to find an exact `OPEN` match, checks the location case-insensitively, and emits to `/queue/match` if valid.

---

### 4. Notification Service (Background Worker)
A headless Node.js service acting strictly as a downstream system alerter.

**Primary Concepts:**
*   **Queue Consumed:** `/queue/match`
*   **Action:** Triggers upon receiving a payload. Currently intercepts the message stream and produces `[NOTIFICATION ALERT]` standard-out logs, notifying the simulated end user that a match for their item was successfully located. Capable of being wired directly into SMTP/SendGrid or push notification architecture here.

---

### 5. Orchestrator Service (Port 3005)
This service manages **Distributed Transactions** using the **Saga Pattern**. Because lost data is in Mongo and found data is in MySQL, you cannot rely on classic ACID database guarantees when a user "claims" an item.

**Endpoints:**
| Method | Route | Action |
| :--- | :--- | :--- |
| `POST` | `/api/saga/return-item` | Executes the Claim Workflow payload: `{ lostItemId, foundItemId }` |

**Saga Mechanism and Rollbacks:**
The orchestrator fires sequential cross-service network requests. If any step fails, it initiates **Compensating Transactions (Rollbacks)**.
*   **Step 1:** Sends `PATCH /lost/:id` to mark Lost item status as `RESOLVED`.
*   **Step 2:** Sends `PATCH /found/:id` to mark Found item status as `RESOLVED`.
*   **Failure State:** If Step 2 fails (e.g., Found Service is down, MySQL rejects row lock), the Orchestrator catches the error and automatically fires a rollback request to `PATCH /lost/:id` with status `OPEN` to revert the system to its initial state, preventing orphaned records.

---

## Technical Tooling Implementation

*   **Message Broker (Event Bus):** Apache ActiveMQ (STOMP Protocol over port 61613). Handled by the `stompit` Node.js package in all services. Features a `connectWithRetry` block (5000ms delay) so services don't crash if the broker spins up slowly.
*   **Fault Tolerance:** Target requests wrap via `Opossum` Circuit Breakers. If failure threshold percentages exceed 50% in a 10s reset window, it trips open, preventing cascading failures across the Node.js event loop.
*   **Database ORMs:** MongoDB handled natively via `Mongoose`. MySQL handled natively via `Sequelize`.
