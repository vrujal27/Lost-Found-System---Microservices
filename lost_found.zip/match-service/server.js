const stompit = require("stompit");
const mongoose = require("mongoose");
const { Sequelize, DataTypes, Op } = require("sequelize");

const connectOptions = {
    host: "activemq",
    port: 61613
};

// Mongoose for LostItem
const lostItemSchema = new mongoose.Schema({ item: String, location: String, status: String });
const LostItem = mongoose.model('LostItem', lostItemSchema);

// Sequelize for FoundItem
const sequelize = new Sequelize('founddb', 'root', 'password', {
  host: 'mysql',
  dialect: 'mysql',
  logging: false
});

const FoundItem = sequelize.define('FoundItem', {
  item: { type: DataTypes.STRING, allowNull: false },
  location: { type: DataTypes.STRING, allowNull: false },
  status: { type: DataTypes.STRING, defaultValue: 'OPEN' }
}, {
  timestamps: true,
  updatedAt: false,
  createdAt: 'createdAt'
});

mongoose.connect('mongodb://mongodb:27017/lostfound')
  .then(() => console.log('Match-Service connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

sequelize.sync()
  .then(() => console.log('Match-Service connected to MySQL'))
  .catch(err => console.error('MySQL connection error:', err));


function connectWithRetry() {
    stompit.connect(connectOptions, (err, client) => {
        if (err) {
            console.log("ActiveMQ not ready, retrying in 5 seconds...");
            setTimeout(connectWithRetry, 5000);
            return;
        }

        console.log("Match Service connected to ActiveMQ");
        startConsumers(client);
    });
}

function startConsumers(client) {
    client.subscribe({ destination: "/queue/lost-items" }, (e, msg) => {
        msg.readString("utf-8", async (e, body) => {
            const lost = JSON.parse(body);
            console.log("Processing new Lost Event:", lost);
            await checkMatchForLost(client, lost);
        });
    });

    client.subscribe({ destination: "/queue/found-items" }, (e, msg) => {
        msg.readString("utf-8", async (e, body) => {
            const found = JSON.parse(body);
            console.log("Processing new Found Event:", found);
            await checkMatchForFound(client, found);
        });
    });
}

async function checkMatchForLost(client, lost) {
    try {
        // Find a matching found item that is OPEN (MySQL case-insensitive by default)
        const matchedFoundItems = await FoundItem.findAll({ 
            where: {
                status: 'OPEN',
                item: lost.item.trim()
            }
        });

        for (const foundModel of matchedFoundItems) {
            const found = foundModel.toJSON();
            found._id = found.id; // Map for Saga compatibility
            if (found.location.toLowerCase().trim() === lost.location.toLowerCase().trim()) {
                sendMatchFound(client, lost, found);
                return; // send first match
            }
        }
    } catch (err) {
        console.error("Error finding match for lost item:", err);
    }
}

async function checkMatchForFound(client, found) {
    try {
        const matchedLostItems = await LostItem.find({ 
            status: 'OPEN',
            item: { $regex: new RegExp('^' + found.item.trim() + '$', 'i') }
        });

        for (const lost of matchedLostItems) {
            if (lost.location.toLowerCase().trim() === found.location.toLowerCase().trim()) {
                sendMatchFound(client, lost, found);
                return; // send first match
            }
        }
    } catch (err) {
         console.error("Error finding match for found item:", err);
    }
}

function sendMatchFound(client, lost, found) {
    console.log("\n========== MATCH FOUND ==========");
    console.log("Lost Item:", lost);
    console.log("Found Item:", found);
    console.log("=================================\n");

    const frame = client.send({ destination: "/queue/match" });
    frame.write(JSON.stringify({ lost, found }));
    frame.end();
}

connectWithRetry();