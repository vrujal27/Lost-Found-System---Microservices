const express = require("express");
const stompit = require("stompit");
const { Sequelize, DataTypes } = require('sequelize');
const CircuitBreaker = require("opossum");

const app = express();
const cors = require("cors");
app.use(cors());
app.use(express.json());

// MySQL Connection via Sequelize
const sequelize = new Sequelize('founddb', 'root', 'password', {
  host: 'mysql',
  dialect: 'mysql',
  logging: false
});

const FoundItem = sequelize.define('FoundItem', {
  item: { type: DataTypes.STRING, allowNull: false },
  location: { type: DataTypes.STRING, allowNull: false },
  status: { type: DataTypes.STRING, defaultValue: 'OPEN' }
}, {
  timestamps: true,
  updatedAt: false,
  createdAt: 'createdAt'
});

sequelize.sync()
  .then(() => console.log('Found-Service connected to MySQL and synced'))
  .catch(err => console.error('MySQL connection error:', err));


const connectOptions = { host: "activemq", port: 61613 };

// Circuit Breaker Function for Message Queue
const sendMessageToQueue = async (destination, data) => {
    return new Promise((resolve, reject) => {
        stompit.connect(connectOptions, (error, client) => {
            if (error) {
                return reject(error);
            }
            const frame = client.send({ destination });
            frame.write(JSON.stringify(data));
            frame.end();
            client.disconnect();
            resolve();
        });
    });
};

const cbOptions = {
    timeout: 3000,
    errorThresholdPercentage: 50,
    resetTimeout: 10000 
};
const messageBreaker = new CircuitBreaker(sendMessageToQueue, cbOptions);

messageBreaker.fallback(() => console.log('Circuit Breaker Fallback: Queue unavailable. Item is saved in DB but match processing is delayed.'));


app.post("/found", async (req, res) => {
    try {
        const newItem = await FoundItem.create(req.body);
        const savedItem = newItem.toJSON();
        savedItem._id = savedItem.id; // Map for frontend

        console.log("Found item saved to DB:", savedItem);

        // Send to queue via Circuit Breaker
        await messageBreaker.fire("/queue/found-items", savedItem);

        res.status(201).json({ message: "Found item reported", data: savedItem });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Saga Endpoint
app.patch("/found/:id", async (req, res) => {
    try {
        const item = await FoundItem.findByPk(req.params.id);
        if (!item) return res.status(404).json({ error: "Item not found" });
        await item.update({ status: req.body.status });
        const data = item.toJSON();
        data._id = data.id;
        res.json({ message: "Status updated", data });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get("/found", async (req, res) => {
    try {
        const items = await FoundItem.findAll();
        const mappedItems = items.map(i => {
           let it = i.toJSON();
           it._id = it.id;
           return it;
        });
        res.json(mappedItems);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.listen(3002, () => {
    console.log("Found Service running on port 3002");
});