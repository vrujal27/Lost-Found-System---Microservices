const express = require('express');
const axios = require('axios');

const app = express();
const cors = require("cors");
app.use(cors());
app.use(express.json());

// Saga Route
app.post('/api/saga/return-item', async (req, res) => {
    const { lostItemId, foundItemId } = req.body;
    let step = 0;

    console.log(`Starting Saga for returning item (Lost: ${lostItemId}, Found: ${foundItemId})`);

    try {
        // Step 1: Mark lost item as resolved
        console.log("Saga Step 1: Updating lost service");
        await axios.patch(`http://lost-service:3001/lost/${lostItemId}`, { status: 'RESOLVED' });
        step = 1;

        // Step 2: Mark found item as resolved
        console.log("Saga Step 2: Updating found service");
        await axios.patch(`http://found-service:3002/found/${foundItemId}`, { status: 'RESOLVED' });
        step = 2;

        console.log("Saga Completed Successfully");
        res.json({ message: "Item successfully returned. Saga completed." });
    } catch (error) {
        console.error("Saga Failed at step:", step + 1, "Error:", error.message);

        // Compensating Transactions (Rollbacks)
        try {
            if (step >= 1) {
                console.log("Compensating Step 1: Reverting lost item status");
                await axios.patch(`http://lost-service:3001/lost/${lostItemId}`, { status: 'OPEN' });
            }
            // If it failed at step 2, step was still 1. So it rolls back step 1.
        } catch (rollbackError) {
            console.error("CRITICAL: Rollback failed! System may be in inconsistent state.", rollbackError.message);
        }

        res.status(500).json({ error: "Saga failed and was rolled back." });
    }
});

app.listen(3005, () => {
    console.log('Orchestrator Service running on port 3005');
});
