const stompit = require('stompit');

const connectOptions = {
    host: 'activemq',
    port: 61613
};

function connectWithRetry() {
    stompit.connect(connectOptions, (err, client) => {
        if (err) {
            console.log("ActiveMQ not ready, Notification Service retrying in 5s...");
            setTimeout(connectWithRetry, 5000);
            return;
        }
        console.log("Notification Service connected to ActiveMQ");
        startConsumer(client);
    });
}

function startConsumer(client) {
    client.subscribe({ destination: "/queue/match" }, (err, msg) => {
        if (err) {
            console.error("Notification subscribe error:", err);
            return;
        }

        msg.readString("utf-8", (err, body) => {
            if (err) {
                console.error("Read string error:", err);
                return;
            }

            const match = JSON.parse(body);
            console.log("\n[NOTIFICATION ALERT] ========================");
            console.log(`Alert sent to: user of Item "${match.lost.item}"`);
            console.log("Good news! Your lost item has been matched.");
            console.log("Found location:", match.found.location);
            console.log("================================================\n");
            
            // In a real system, we might connect to an SMTP server here (e.g., Sendgrid, Nodemailer)
            // or send a Push Notification.
        });
    });
}

connectWithRetry();
