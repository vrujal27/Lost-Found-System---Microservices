const express = require("express");
const stompit = require("stompit");
const mongoose = require("mongoose");
const CircuitBreaker = require("opossum");
const redis = require("redis");

const app = express();
const cors = require("cors");
app.use(cors());
app.use(express.json());

// MongoDB Schema
const lostItemSchema = new mongoose.Schema({
    item: { type: String, required: true },
    location: { type: String, required: true },
    status: { type: String, default: 'OPEN' }, // OPEN, RESOLVED
    createdAt: { type: Date, default: Date.now }
});
const LostItem = mongoose.model('LostItem', lostItemSchema);

// MongoDB Connection
mongoose.connect('mongodb://mongodb:27017/lostfound')
  .then(() => console.log('Lost-Service connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Redis Connection
const redisClient = redis.createClient({ url: 'redis://redis:6379' });
redisClient.connect()
  .then(() => console.log('Lost-Service connected to Redis'))
  .catch(err => console.error('Redis connection error:', err));


const connectOptions = { host: "activemq", port: 61613 };

// Circuit Breaker Function
const sendMessageToQueue = async (destination, data) => {
    return new Promise((resolve, reject) => {
        stompit.connect(connectOptions, (error, client) => {
            if (error) {
                return reject(error);
            }
            const frame = client.send({ destination });
            frame.write(JSON.stringify(data));
            frame.end();
            client.disconnect();
            resolve();
        });
    });
};

const cbOptions = {
    timeout: 3000,
    errorThresholdPercentage: 50,
    resetTimeout: 10000 
};
const messageBreaker = new CircuitBreaker(sendMessageToQueue, cbOptions);

messageBreaker.fallback(() => console.log('Circuit Breaker Fallback: Message queue is unavailable right now.'));


app.post("/lost", async (req, res) => {
    try {
        const newItem = new LostItem(req.body);
        const savedItem = await newItem.save();

        console.log("Lost item saved to DB:", savedItem);
        
        // Invalidate cache
        await redisClient.del("lost_items").catch(console.error);

        // Send to queue via Circuit Breaker
        await messageBreaker.fire("/queue/lost-items", savedItem);

        res.status(201).json({ message: "Lost item reported", data: savedItem });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Saga Endpoint
app.patch("/lost/:id", async (req, res) => {
    try {
        const item = await LostItem.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
        if (!item) return res.status(404).json({ error: "Item not found" });
        
        // Invalidate cache
        await redisClient.del("lost_items").catch(console.error);
        
        res.json({ message: "Status updated", data: item });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get("/lost", async (req, res) => {
    try {
        const cachedItems = await redisClient.get("lost_items").catch(console.error);
        if (cachedItems) {
            console.log("Serving from Redis cache");
            return res.json(JSON.parse(cachedItems));
        }

        const items = await LostItem.find();
        
        // Cache for 60 seconds
        await redisClient.setEx("lost_items", 60, JSON.stringify(items)).catch(console.error);
        
        res.json(items);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.listen(3001, () => {
    console.log("Lost Service running on port 3001");
});